<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<div class="space-y-6">
    <div class="flex justify-between items-center">
        <h2 class="text-xl font-bold text-white">Manage Channels</h2>
        <button onclick="toggleModal('addChannelModal')" class="bg-indigo-600 px-4 py-2 rounded-xl text-white">+ Add New Channel</button>
    </div>

    <div class="bg-slate-900/50 border border-white/5 rounded-2xl overflow-hidden shadow-xl">
        <table class="w-full text-slate-300">
            <thead class="bg-white/5 text-xs uppercase">
                <tr>
                    <th class="px-6 py-4">Logo</th>
                    <th class="px-6 py-4">Name</th>
                    <th class="px-6 py-4">Category</th>
                    <th class="px-6 py-4 text-center">Action</th>
                </tr>
            </thead>
            <tbody id="channel-list" class="divide-y divide-white/5"></tbody>
        </table>
    </div>
</div>

<div id="addChannelModal" class="fixed inset-0 bg-black/60 hidden flex items-center justify-center z-50">
    <div class="bg-slate-900 p-6 w-full max-w-lg rounded-2xl border border-white/10">
        <h3 class="text-white font-bold mb-4">Add Channel</h3>
        <form id="addChannelForm" class="grid grid-cols-2 gap-4">
            <input type="text" name="name" placeholder="Channel Name" class="col-span-2 w-full bg-slate-800 p-3 rounded text-white" required>
            <input type="text" name="category_id" placeholder="Category ID" class="w-full bg-slate-800 p-3 rounded text-white">
            <input type="text" name="logo_url" placeholder="Logo URL" class="w-full bg-slate-800 p-3 rounded text-white">
            <button type="submit" class="col-span-2 bg-indigo-600 py-3 rounded text-white font-bold">Save</button>
            <button type="button" onclick="toggleModal('addChannelModal')" class="col-span-2 text-slate-400">Cancel</button>
        </form>
    </div>
</div>

<div id="editChannelModal" class="fixed inset-0 bg-black/60 hidden flex items-center justify-center z-50">
    <div class="bg-slate-900 p-6 w-full max-w-lg rounded-2xl border border-white/10">
        <h3 class="text-white font-bold mb-4">Edit Channel</h3>
        <form id="editChannelForm" class="grid grid-cols-2 gap-4">
            <input type="hidden" name="id" id="edit_id">
            <input type="text" name="name" id="edit_name" class="col-span-2 w-full bg-slate-800 p-3 rounded text-white">
            <input type="text" name="category_id" id="edit_category_id" class="w-full bg-slate-800 p-3 rounded text-white">
            <button type="submit" class="col-span-2 bg-green-600 py-3 rounded text-white font-bold">Update</button>
            <button type="button" onclick="toggleModal('editChannelModal')" class="col-span-2 text-slate-400">Cancel</button>
        </form>
    </div>
</div>

<script>
function toggleModal(id) { $('#' + id).toggleClass('hidden'); }

// 1. লিস্ট লোড করা
function loadChannels() {
    $.get('<?= base_url("admin/get_channels_ajax") ?>', function(res) {
        let data = JSON.parse(res);
        let rows = '';
        data.channels.forEach(c => {
            rows += `<tr>
                <td class="px-6 py-4"><img src="${c.logo_url}" class="w-10 h-10 rounded"></td>
                <td class="px-6 py-4">${c.name}</td>
                <td class="px-6 py-4">${c.category_id}</td>
                <td class="px-6 py-4 text-center">
                    <button onclick='openEditModal(${JSON.stringify(c)})' class="text-blue-400">Edit</button>
                    <button onclick="confirmDelete(${c.id})" class="text-red-400 ml-4">Delete</button>
                </td>
            </tr>`;
        });
        $('#channel-list').html(rows);
    });
}

// 2. এডিট মোডাল ওপেন
function openEditModal(c) {
    $('#edit_id').val(c.id);
    $('#edit_name').val(c.name);
    $('#edit_category_id').val(c.category_id);
    toggleModal('editChannelModal');
}

// 3. ডিলিট কনফার্মেশন
function confirmDelete(id) {
    Swal.fire({
        title: 'Are you sure?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post('<?= base_url("admin/delete_channel_ajax/") ?>' + id, function() {
                loadChannels();
                Swal.fire('Deleted!', '', 'success');
            });
        }
    });
}

// 4. ফর্ম সাবমিট (Add & Edit)
$('#addChannelForm, #editChannelForm').submit(function(e) {
    e.preventDefault();
    let url = $(this).attr('id') === 'addChannelForm' ? 'add_channel_ajax' : 'edit_channel_ajax';
    $.post('<?= base_url("admin/") ?>' + url, $(this).serialize(), function() {
        $('#addChannelModal, #editChannelModal').addClass('hidden');
        loadChannels();
        Swal.fire('Success!', 'Operation completed.', 'success');
    });
});

$(document).ready(loadChannels);
</script>